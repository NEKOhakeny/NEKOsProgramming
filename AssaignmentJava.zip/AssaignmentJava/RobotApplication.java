class RobotApplication{
    public static void main(String[] args){
        Robot r1 = new Robot();
        Robot r2 = new Robot();
        r1.setId(1);
        r2.setId(2);
        r1.printId();
        r2.printId();
    }
}