public class TwirlingRobot
{
    int x,y,dir;
    Robot robot = new Robot();
    void setId(int id){
        robot.setId(id);
    }
    void initialize(int x,int y,int dir)
    {
        this.x = x;
        this.y = y;
        this.dir = dir;
    }
    void turnLeft()
    {
        dir = (dir + 1) % 4;
    }
    void turnRight()
    {
        dir = (dir - 1) % 4;
    }
    void move()
    {
        if(dir == 0 || dir == 2)y -= dir - 1;
        else x -= dir - 2;
    }
    void printLocation()
    {
        System.out.printf("Robot %d is at (%d,%d)",robot.id,this.x,this.y);
        System.out.println("");
    }
    


}