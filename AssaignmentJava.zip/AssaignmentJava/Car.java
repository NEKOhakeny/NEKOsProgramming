public class Car
{
    double speed = 0.0;
    double fuelConsumption = 12.0;
    double gasTank = 60.0;
    double travelledTime = 0.0;

    public void speedUp(int addSpeed)
    {
        this.speed += addSpeed;
    }
    public void applyBrakes(int declSpeed)
    {
        this.speed -= declSpeed;
    }
    public void travelledTimeUp(int addTime)
    {
        this.travelledTime = addTime;
    }
    public void printStateTank()
    {
        double fuel = speed * travelledTime / fuelConsumption;
        System.out.println(gasTank - fuel);
    }
    
}


